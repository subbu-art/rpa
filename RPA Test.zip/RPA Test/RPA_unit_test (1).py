# -*- coding: utf-8 -*-
"""
Created on Wed Dec 30 15:39:25 2020

@author: pkansal
"""

import requests
import json
import time
import os
from dotenv import load_dotenv

dotenv_path = os.path.join(r'C:\Users\ppinnint\OneDrive - Capgemini\Desktop\RPA Test\.env')
load_dotenv(dotenv_path)

class CommunityOrchestratorAPI:
    def __init__(self, tenant_name, tenant_email, ServiceName, AccountName, tenant_password, owner_name):
        self.ServiceName = ServiceName
        self.AccountName = AccountName
        self.tenant_name = tenant_name
        self.tenant_email = tenant_email
        self.tenant_password = tenant_password
        self.owner_name = owner_name
        self.token = ""
        self.robot_ID = ""
        self.process_ID = ""
        
    def getUserToken(self):
        url = furl = r"https://platform.uipath.com/{self.owner_name}/{self.tenant_name}/api/Account/Authenticate"
        user_data = f"""{{
        "tenancyName": "{self.tenant_name}",
        "usernameOrEmailAddress": "{self.tenant_email}",
        "password": "{self.tenant_password}"
        }}"""
        data = requests.post(url, json=json.loads(user_data),
                             headers={"X-UIPATH-TenantName": f"{self.AccountName}",
                                      "Content-Type": "application/json"})
        print(data.text)
        authentication_data = json.loads(data.text)
        self.token = "Bearer " + str(authentication_data["result"])
        print(self.token)
        
        return token

    def getProcessID(self, process_name):
        process_data =requests.get(f"https://platform.uipath.com/odata/Releases?$filter=ProcessKey+eq%20'{process_name}'",
                                headers={"Authorization": token})
        process_json = json.loads(process_data.text)  
        self.process_ID = process_json["value"][0]["Key"]
        return

    def getRobotID(self, robotName):
        robot_name =robot_name = requests.get(f"https://platform.uipath.com/odata/Robots?$filter=Name%20eq%20'{robotName}'",
                            headers={"Authorization": token})
        robot_json_obj = json.loads(robot_name.text)
        self.robot_ID = robot_json_obj["value"][0]["Id"]
        return

    def getQueueID(self, queueName):
        queue_data = requests.get(f"https://platform.uipath.com/{self.AccountName}/{self.ServiceName}/odata/QueueDefinitions?$filter=Name%20eq%20'{queueName}'", headers={"Authorization": self.token,
                                           "X-UIPATH-TenantName": f"{self.ServiceName}",
                                           "Content-Type": "application/json"})
        
        queue_json_obj = json.loads(queue_data.text)
        self.queue_ID = queue_json_obj["value"][0]["Id"]
        return

    
    def add_queue_item(self, queue_name, inv_no, inv_dt, vendor):
        payload = """{
                        "itemData": {
                            "Name": \"""" + queue_name + """\",
                            "Priority": "Normal",
                            "SpecificContent": {
                                "InvoiceNumber": \"""" + inv_no+ """\",
                        		"InvoiceDate": \"""" + inv_dt + """\",
                                "VendorName": \"""" + vendor + """\"
                            }
                        }
                    }"""
        queue_data = requests.post(f"https://platform.uipath.com/{self.AccountName}/{self.ServiceName}/odata/Queues/UiPathODataSvc.AddQueueItem", json=json.loads(payload), 
                                headers={"Authorization": self.token, 
                                         "X-UIPATH-TenantName": f"{self.ServiceName}", 
                                         "Content-Type": "application/json"})
        if queue_data.status_code == 201:
            self.ItemID = json.loads(queue_data.content)["Id"]
            return("Item added to queue successfully")
        else:
            self.ItemID = None
            return("Item addition to queue failed")
    
    def get_queue_data(self):
        queue_data = requests.get(f"https://platform.uipath.com/{self.AccountName}/{self.ServiceName}/odata/QueueItems?$filter=QueueDefinitionId%20eq%20{self.queue_ID}",
                                  headers={"Authorization": self.token,
                                           "X-UIPATH-TenantName": f"{self.ServiceName}",
                                           "Content-Type": "application/json"})
        queue_json_obj = json.loads(queue_data.text)
        self.queueData = queue_json_obj["value"][0]
        return




timeout = int(os.getenv('ELAPSE_TIME'))
disconnect_time = int(os.getenv('DISCONNECT_TIME'))
tenant_name = os.getenv('TENANT_NAME')
owner_name = os.getenv('OWNER_NAME')
tenant_email = os.getenv('TENANT_EMAIL')
tenant_password = os.getenv('TENANT_PASSWORD')
queueName = os.getenv('QUEUENAME')
ServiceName = os.getenv('SERVICENAME')
AccountName = os.getenv('ACCOUNTNAME')
processName = os.getenv('PROCESSNAME')
robotName = os.getenv('ROBOTNAME')

def RPA_connect():
    print("initializing bot...")
    try:
        obj = CommunityOrchestratorAPI(tenant_name, tenant_email, ServiceName, AccountName, tenant_password, owner_name)
        obj.getUserToken()
        obj.getProcessID(processName)
        obj.getRobotID(robotName)
        obj.getQueueID(queueName)
        return(obj)
    except:
        print("Failed to initialize. Please check env variables and your internet connection")
        return
        
        
def fetch_result(inv_no, inv_dt, vendor):
    
    # Making connection to RPA orchestrator
    obj = RPA_connect()

    try:
        # Triggering bot by adding queue item
        res = obj.add_queue_item(queueName, inv_no=inv_no, inv_dt=inv_dt, vendor=vendor)
        print(res)
        itemID = None
        output = None
        cnt = 1
        # Checking bot for response
        print("Checking for response")
        while not ((itemID == obj.ItemID) and (output != None)):
            time.sleep(timeout)
            obj.get_queue_data()
            itemID = obj.queueData['Id']
            output = obj.queueData['Output']
            print('Total Time elapsed: {} seconds. Retrying after {} sec'.format(cnt*timeout, timeout))
            if cnt > (disconnect_time//timeout):
                print("Terminating the request as exceeded disconnect time")
                return
            cnt += 1
        f_out = {}
        for i in output:
            if output[i]:
                if i == 'InvoiceStatus':
                    f_out['status'] = output[i].lower()
                else:
                    f_out[i] = output[i]
        return(f_out)
    except Exception as e:
        return "Error occured: " + str(e)
        
fetch_result(inv_no='XYZ50000', inv_dt='05/10/2020'+' 00:00:00', vendor='molex')

# https://medium.com/@ishmeet1995/run-a-uipath-job-using-python-community-edition-23c3989cbccd