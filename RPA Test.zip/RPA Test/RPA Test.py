import requests
import json
import time
import os
from dotenv import load_dotenv

dotenv_path = os.path.join(r'C:\Users\ppinnint\OneDrive - Capgemini\Desktop\RPA Test\.env')
load_dotenv(dotenv_path)


def getUserToken(URL, user_data):
    data = requests.post(url, json=json.loads(user_data))
    authentication_data = json.loads(data.text)
    token = "Bearer " + str(authentication_data["result"])
    return


def getProcessID(process_name, token):
    process_data = requests.get(f"https://platform.uipath.com/odata/Releases?$filter=ProcessKey+eq%20'{process_name}'",
                                headers={"Authorization": token})
    process_json = json.loads(process_data.text)
    # print(json.dumps(process_json, indent=2))
    process_ID = process_json["value"][0]["Key"]
    return process_ID


def getRobotID(robotName, token):
    robot_name = requests.get(f"https://platform.uipath.com/odata/Robots?$filter=Name%20eq%20'{robotName}'",
                              headers={"Authorization": token})
    robot_json_obj = json.loads(robot_name.text)
    robot_ID = robot_json_obj["value"][0]["Id"]
    return robot_ID




def getQueueID(queueName, ServiceName, AccountName, token):
    queue_data = requests.get(f"https://platform.uipath.com/{AccountName}/{ServiceName}/odata/QueueDefinitions?$filter=Name%20eq%20'{queueName}'", headers={"Authorization": self.token,
                                       "X-UIPATH-TenantName": f"{ServiceName}",
                                       "Content-Type": "application/json"})
    
    queue_json_obj = json.loads(queue_data.text)
    queue_ID = queue_json_obj["value"][0]["Id"]
    return


def add_queue_item(queue_name, inv_no, inv_dt, vendor, AccountName, ServiceName, token):
    payload = """{
                    "itemData": {
                        "Name": \"""" + queue_name + """\",
                        "Priority": "Normal",
                        "SpecificContent": {
                            "InvoiceNumber": \"""" + XYZ50000 + """\",
                            "InvoiceDate": \"""" + inv_dt + """\",
                            "VendorName": \"""" + capgemini + """\"
                        }
                    }
                }"""
    queue_data = requests.post(f"https://platform.uipath.com/{AccountName}/{ServiceName}/odata/Queues/UiPathODataSvc.AddQueueItem", json=json.loads(payload), 
                            headers={"Authorization": token, 
                                     "X-UIPATH-TenantName": f"{ServiceName}", 
                                     "Content-Type": "application/json"})
    if queue_data.status_code == 201:
        self.ItemID = json.loads(queue_data.content)["Id"]
        return("Item added to queue successfully")
    else:
        self.ItemID = None
        return("Item addition to queue failed")

def get_queue_data(AccountName, ServiceName, queue_ID, token):
    queue_data = requests.get(f"https://platform.uipath.com/{AccountName}/{ServiceName}/odata/QueueItems?$filter=QueueDefinitionId%20eq%20{queue_ID}",
                              headers={"Authorization": token,
                                       "X-UIPATH-TenantName": f"{ServiceName}",
                                       "Content-Type": "application/json"})
    queue_json_obj = json.loads(queue_data.text)
    queueData = queue_json_obj["value"][0]
    return
    
def runJob(process_ID, robot_ID, token):
    start_job_json = """{ "startInfo":
       { "ReleaseKey": \"""" + process_ID + """\",
         "Strategy": "Specific",
         "RobotIds": [ """ + str(robot_ID) + """ ],
         "Source": "Manual",
         "InputArguments": "{'in_Arg1':'Aloha'}"        
       } 
    }"""   
    #InputArguments should be left {} or not included if workflow does not accept any input
    start_job_data = requests.post("https://platform.uipath.com/odata/Jobs/UiPath.Server.Configuration.OData.StartJobs",
                                   json=json.loads(start_job_json), headers={"Authorization": token})
    return start_job_data




tenant_name = os.getenv('TENANT_NAME')
owner_name = os.getenv('OWNER_NAME')
tenant_email = os.getenv('TENANT_EMAIL')
tenant_password = os.getenv('TENANT-PASSWORD')
queueName = os.getenv('QUEUENAME')
ServiceName = os.getenv('SERVICENAME')
AccountName = os.getenv('ACCOUNTNAME')
ProcessName = os.getenv('PROCESSNAME')
RobotName = os.getenv('ROBOTNAME')

url = furl = r"https://platform.uipath.com/{owner_name}/{tenant_name}/api/Account/Authenticate"
user_data = f"""{{
        "tenancyName": "{tenant_name}",
        "usernameOrEmailAddress": "{tenant_email}",
        "password": "{tenant_password}"
    }}"""
token = getUserToken(url, user_data)

process_name = ProcessName
process_ID = getProcessID(process_name, token)

robot_name = RobotName
robot_ID = getRobotID(robot_name, token)

start_job_data = runJob(process_ID, robot_ID, token)
